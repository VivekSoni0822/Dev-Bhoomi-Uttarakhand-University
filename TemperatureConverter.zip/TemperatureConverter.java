import java.util.Scanner;

public class TemperatureConverter {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter the temperature value:");
        double temperature = scanner.nextDouble();
        scanner.nextLine(); // consume the newline

        System.out.println("Is the unit of measurement Celsius or Fahrenheit? (C/F):");
        String unit = scanner.nextLine().toUpperCase();

        if (unit.equals("C")) {
            double fahrenheit = celsiusToFahrenheit(temperature);
            System.out.printf("%.2f Celsius is equal to %.2f Fahrenheit%n", temperature, fahrenheit);
        } else if (unit.equals("F")) {
            double celsius = fahrenheitToCelsius(temperature);
            System.out.printf("%.2f Fahrenheit is equal to %.2f Celsius%n", temperature, celsius);
        } else {
            System.out.println("Invalid unit of measurement. Please enter 'C' for Celsius or 'F' for Fahrenheit.");
        }

        scanner.close();
    }

    private static double celsiusToFahrenheit(double celsius) {
        return (celsius * 9 / 5) + 32;
    }

    private static double fahrenheitToCelsius(double fahrenheit) {
        return (fahrenheit - 32) * 5 / 9;
    }
}