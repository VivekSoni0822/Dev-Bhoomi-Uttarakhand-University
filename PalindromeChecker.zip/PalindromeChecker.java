import java.util.Scanner;

public class PalindromeChecker {

    // Function to check if a string is a palindrome
    public static boolean isPalindrome(String s) {
        // Step 1: Normalize the input string
        String normalizedStr = "";
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (Character.isLetterOrDigit(c)) {
                normalizedStr += Character.toLowerCase(c);
            }
        }

        // Step 2: Check if the normalized string is a palindrome
        int len = normalizedStr.length();
        for (int i = 0; i < len / 2; i++) {
            if (normalizedStr.charAt(i) != normalizedStr.charAt(len - i - 1)) {
                return false; // Conditional statement
            }
        }
        return true; // If no mismatches, it is a palindrome
    }

    public static void main(String[] args) {
        // Step 3: Read input from the user
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter a word or phrase to check if it is a palindrome: ");
        String input = scanner.nextLine();

        // Step 4: Check if the input is a palindrome and display the result
        if (isPalindrome(input)) {
            System.out.println("It's a palindrome!");
        } else {
            System.out.println("It's not a palindrome.");
        }

        // Close the scanner
        scanner.close();
    }
}