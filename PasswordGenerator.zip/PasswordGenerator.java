import java.util.Random;
import java.util.Scanner;

public class PasswordGenerator {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter the desired length of the password:");
        int length = scanner.nextInt();

        System.out.println("Include lowercase letters? (yes/no):");
        boolean includeLowercase = scanner.next().equalsIgnoreCase("yes");

        System.out.println("Include uppercase letters? (yes/no):");
        boolean includeUppercase = scanner.next().equalsIgnoreCase("yes");

        System.out.println("Include numbers? (yes/no):");
        boolean includeNumbers = scanner.next().equalsIgnoreCase("yes");

        System.out.println("Include special characters? (yes/no):");
        boolean includeSpecialChars = scanner.next().equalsIgnoreCase("yes");

        String password = generatePassword(length, includeLowercase, includeUppercase, includeNumbers, includeSpecialChars);
        System.out.println("Generated Password: " + password);

        scanner.close();
    }

    private static String generatePassword(int length, boolean includeLowercase, boolean includeUppercase, boolean includeNumbers, boolean includeSpecialChars) {
        String lowercase = "abcdefghijklmnopqrstuvwxyz";
        String uppercase = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        String numbers = "0123456789";
        String specialChars = "!@#$%^&*()-_=+[]{}|;:,.<>?/";

        StringBuilder characterSet = new StringBuilder();
        Random random = new Random();

        if (includeLowercase) {
            characterSet.append(lowercase);
        }
        if (includeUppercase) {
            characterSet.append(uppercase);
        }
        if (includeNumbers) {
            characterSet.append(numbers);
        }
        if (includeSpecialChars) {
            characterSet.append(specialChars);
        }

        if (characterSet.length() == 0) {
            throw new IllegalArgumentException("At least one character set must be selected.");
        }

        StringBuilder password = new StringBuilder();
        for (int i = 0; i < length; i++) {
            int index = random.nextInt(characterSet.length());
            password.append(characterSet.charAt(index));
        }

        return password.toString();
    }
}
